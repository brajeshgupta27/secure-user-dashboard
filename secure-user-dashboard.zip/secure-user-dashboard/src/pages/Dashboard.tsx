import React, { useEffect, useState } from 'react';
import { useUserStore } from '../store';
import { getUserData } from '../services/api';
import { useNavigate } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const user = useUserStore((state) => state.user);
  const [userData, setUserData] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/signin');
      return;
    }

    const fetchData = async () => {
      try {
        const data = await getUserData(user.id);
        setUserData(data);
      } catch (error) {
        console.error('Failed to fetch user data:', error);
      }
    };

    fetchData();
},[user]);
  }, [user, navigate]);

  if (!userData) return <div>Loading...</div>;

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Dashboard</h1>
      <p>Welcome, {userData.data.first_name} {userData.data.last_name}</p>
    </div>
  );
};

export default Dashboard;
