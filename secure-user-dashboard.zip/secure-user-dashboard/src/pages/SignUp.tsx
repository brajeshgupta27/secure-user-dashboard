import React, { useState } from 'react';
import { register } from '../services/api';
import { useUserStore } from '../store';
import { useNavigate } from 'react-router-dom';

const SignUp: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const setUser = useUserStore((state) => state.setUser);
  const navigate = useNavigate();

  const handleSignUp = async () => {
    try {
      const data = await register(email, password);
      setUser(data);
      navigate('/dashboard');
    } catch (error) {
      console.error('Sign Up Failed:', error);
    }
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <h1 className="text-xl font-bold">Sign Up</h1>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="block w-full mt-2 mb-2 p-2 border rounded"
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="block w-full mt-2 mb-2 p-2 border rounded"
      />
      <button
        onClick={handleSignUp}
        className="w-full p-2 bg-green-500 text-white rounded"
      >
        Sign Up
      </button>
    </div>
  );
};

export default SignUp;
