import React, { useState } from 'react';
import { useUserStore } from '../store';
import { login } from '../services/api';
import { useNavigate } from 'react-router-dom';

const SignIn: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const setUser = useUserStore((state) => state.setUser);
  const navigate = useNavigate();

  const handleSignIn = async () => {
    try {
      const data = await login(email, password);
      setUser(data);
      navigate('/dashboard');
    } catch (error) {
      console.error('Sign In Failed:', error);
    }
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <h1 className="text-xl font-bold">Sign In</h1>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="block w-full mt-2 mb-2 p-2 border rounded"
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="block w-full mt-2 mb-2 p-2 border rounded"
      />
      <button
        onClick={handleSignIn}
        className="w-full p-2 bg-blue-500 text-white rounded"
      >
        Sign In
      </button>
    </div>
  );
};

export default SignIn;
